package com.academiaandroid.consultasmysql;


import android.os.AsyncTask;
import android.util.Log;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

public class ConexionAsincrona extends AsyncTask<String, Void, String[][]>
{
    private Connection conexionMySQL;

    @Override
    protected String[][] doInBackground(String... datos)
    {
        String SERVIDOR = datos[0];
        String PUERTO = datos[1];
        String BD = datos[2];
        String USUARIO = datos[3];
        String PASSWORD =datos[4];
        String dia_semana = datos[5];
        String [][] datos_salida = new String[10][2];
         //Inicializamos array de semanas
        for (int j=0;j<10;j++){
            for(int k=0;k<2;k++){
                datos_salida[j][k]= null;

            }
        }

        switch (dia_semana){
            case "LUNES": dia_semana="0";break;
            case "MARTES": dia_semana="1";break;
            case "MIERCOLES": dia_semana="2";break;
            case "JUEVES": dia_semana="3";break;
            case "VIERNES": dia_semana="4";break;
            case "SABADO": dia_semana="5";break;
            case "DOMINGO": dia_semana="6";break;
            default: dia_semana="0";break;

        }
        String hora1 = datos[7];
        String hora2 = datos[6];

        String out = null;
        boolean estadoConexion = false;
        String driver = "com.mysql.jdbc.Driver";
        try {
            Class.forName(driver).newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try{
            /*Establecemos la conexión con el Servidor MySQL indicándole la cadena de conexión formada por la dirección ip,
            puerto del servidor, la base de datos a la que vamos a conectarnos, y el usuario y contraseña de acceso al servidor.*/
            conexionMySQL = DriverManager.getConnection("jdbc:mysql://" + SERVIDOR + ":" + PUERTO + "/" + BD,
                    USUARIO,PASSWORD);

            if(!conexionMySQL.isClosed())
            {
                estadoConexion = true;
                String query = "select * from user where (weekday(discovered_at) = ";
                query = query + dia_semana + " and (Hour(discovered_at) >= " + hora1;
                query = query + " and Hour(discovered_at) <= "+hora2+ "))";
                //String query = "select * from user";
                Statement preparedStmt = conexionMySQL.createStatement();
                ResultSet rs = (ResultSet) preparedStmt.executeQuery(query);
                String semana = null;
                int x =0;
                int y = 0;
                int num_usuarios = 0;
                Date semana_ref = null;
                Date semana_act = null;
                Timestamp stamp;

                while(rs.next()){
                    //El primer dato devuelto
                    out = rs.getInt (1) + " " + rs.getString (2)+ " " + rs.getString(3) + " "+rs.getString(4) + " " +rs.getTimestamp(5)+ " " +rs.getTimestamp(6);

                    if (y==0){
                        stamp = rs.getTimestamp(5);
                        semana_ref = new Date(stamp.getTime());
                        datos_salida[x][0]=semana_ref.toString();
                        y++;
                    }

                    //Tomamos la fecha
                    stamp = rs.getTimestamp(5);
                    semana_act = new Date(stamp.getTime());
                    //Comparamos con la semana de referencia para sumar las personas o separar a otra semnana nueva
                    if(semana_ref.toString().equals(semana_act.toString())){
                        num_usuarios = num_usuarios + 1;
                    }else if(x<10){
                        semana_ref=new Date(stamp.getTime());
                        datos_salida[x][1]=Integer.toString(num_usuarios);
                        num_usuarios =0;
                        x++;
                        semana_ref=new Date(stamp.getTime());
                        datos_salida[x][0]=semana_ref.toString();

                    }

                }

                if(x==10){
                    datos_salida[x-1][1]=Integer.toString(num_usuarios);
                }else{
                    datos_salida[x][1]=Integer.toString(num_usuarios);
                }


            }
        }catch(SQLException ex)
        {
            Log.d("No ha sido posible conectar con la base de datos", ex.getMessage());
        }
        finally
        {
            try
            {
                conexionMySQL.close();
            } catch (SQLException e)
            {
                e.printStackTrace();
            }


        }



        return datos_salida;
    }

    private void onPostExecute(Integer res) {


    }

}
