package com.academiaandroid.consultasmysql;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.concurrent.ExecutionException;

public class User_Window extends ActionBarActivity {

    TextView hora1, hora2;
    Button calcular, TTR,rangohr;
    Spinner spinner;

    private Connection conexion_mysql;
    private boolean conexion_dbtfm = false;
    private String dia_semana = null;
    private String user = "root";
    private String password = "aspire5920";
    private String puerto = "3306";
    private String ip = "192.168.1.129";
    private String baseDatos = "DB_TFM";
     int hora_1,hora_2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__window);
        setTitle("Crowded APP - Selección de datos");

        //Spinner para elegir el dia de la semana
        spinner = (Spinner) findViewById(R.id.dia_semana);
        String[] days = {"LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO", "DOMINGO"};
        spinner.setAdapter(new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, days));
        //EditText para elegir el rango de hora
        hora1 = (TextView) findViewById(R.id.hora1);
        hora2 = (TextView) findViewById(R.id.hora2);
        //Asignación de botones
        calcular = (Button) findViewById(R.id.boton_calcular);
        TTR = (Button) findViewById(R.id.boton_TR);
        rangohr =(Button) findViewById(R.id.btn_rangohr);
        //Pulsación botón calcular
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btncalcular_fnc();
            }
        });
        //Pulsación botón TTR
        TTR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnTR_fnc();
            }
        });
        //Pulsación botón rango horario
        rangohr.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                btnrango_hr();
            }
        });



    }

    public void btnTR_fnc() {
        //Abrimos la activity para mostrar los datos en tiempo real
        Intent intent = new Intent(this,TiempoReal.class);
        startActivity(intent);

    }


    public void btncalcular_fnc() {

        dia_semana = String.valueOf(spinner.getSelectedItem());
        //Llamamos a la función asíncrona para realizar las consultas
        conectarMySQL(dia_semana,hora_1,hora_2);

    }

    public void btnrango_hr() {
        //Creamos instancia de calendario para poder extraer la hora y el día y así almacenarla
        final Calendar c = Calendar.getInstance();
        int hora = c.get(Calendar.HOUR_OF_DAY);
        int minutos = c.get(Calendar.MINUTE);


        TimePickerDialog timePickerDialog = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener(){

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hora1.setText(hourOfDay+":"+minute);
                hora_1 = hourOfDay;
            }
        },hora,minutos,true);
        timePickerDialog.show();


        //Creamos instancia de calendario para poder extraer la hora y el día y así almacenarla
        final Calendar c1 = Calendar.getInstance();
        final int hora1 = c1.get(Calendar.HOUR_OF_DAY);
        int minutos1= c1.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog1 = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener(){

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hora2.setText(hourOfDay+":"+minute);
                hora_2=hourOfDay;
            }
        },hora1,minutos1,true);
        timePickerDialog1.show();



        if (hora_2 <= hora_1){
            Toast toast =
                    Toast.makeText(getApplicationContext(),
                            "La hora final debe ser mayor que la inicial", Toast.LENGTH_SHORT);

            toast.show();

        }

    }



    //Función que establecerá la conexión con el Servidor si los datos introducidos son correctos.
    //Devuelve un valor de verdadero o falso que indicará si se ha establecido la conexión

    public boolean conectarMySQL(String dia, int hora1,int hora2) {
        /*Variable boolean que almacenará si el estado de la conexión es true o false.*/
        String [][] datos_grafica = null;

        /*Asignamos el driver a una variable de tipo String.*/
        String driver = "com.mysql.jdbc.Driver";
        try {
            /*Cargamos el driver del conector JDBC.*/
            Class.forName(driver).newInstance();
            String[] datos = new String[]{ip, puerto, baseDatos, user, password,dia,Integer.toString(hora1),Integer.toString(hora2)};
            datos_grafica = new ConexionAsincrona().execute(datos).get();

        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //Llamamos a la activity para mostrar la gráfica
        Intent intent = new Intent(this,Graphics.class);
        Bundle mBundle = new Bundle();
        mBundle.putSerializable("datosgrafica", datos_grafica);
        intent.putExtras(mBundle);
        startActivity(intent);

        return true;
    }
}