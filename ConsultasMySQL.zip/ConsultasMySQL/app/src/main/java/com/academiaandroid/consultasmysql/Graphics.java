package com.academiaandroid.consultasmysql;

import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Graphics extends ActionBarActivity {
    private BarChart barChart;
    private int [] people;
    private String [][] valores_grafica=null;
    private int maximo =0;
    private int cont =0;
    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Crowded APP - Gráfica de afluencia");
        setContentView(R.layout.activity_graphics);
        bundle = getIntent().getExtras();
        valores_grafica = (String[][]) bundle.getSerializable("datosgrafica");
        barChart = (BarChart) findViewById(R.id.graphic_bar);
        cont =0;
        for(int i=0;i<10;i++){
            if(valores_grafica[i][0]!=null){
                cont++;
                if(Integer.parseInt(valores_grafica[i][1])>maximo){
                    maximo = Integer.parseInt(valores_grafica[i][1]);
                }
            }
        }
        String []weeks = new String[cont];
        for(int i=0;i<cont;i++){
            if(valores_grafica[i][0]!=null){
                weeks[i] =valores_grafica[i][0];
            }
        }


        createCharts(weeks);
    }

    private Chart getSameChart(Chart chart, String description, int textColor, int background, int animacion){
        chart.getDescription().setText(description);
        chart.getDescription().setTextSize(15);
        chart.getDescription().setPosition(1.0f,1.0f);
        chart.setBackgroundColor(background);
        chart.animateY(animacion);
        legend(chart);
        return chart;
    }
    private void legend(Chart chart){

        Legend legend = chart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        ArrayList<LegendEntry> entries = new ArrayList<>();
        for (int i =0;i<10;i++){
            if(valores_grafica[i][0]!=null){
                LegendEntry entry = new LegendEntry();
                entry.formColor=Color.BLUE;
                entry.label = valores_grafica[i][0];
                entries.add(entry);
            }
        }
        legend.setCustom(entries);
    }

    private ArrayList <BarEntry> getBarEntries(){
            ArrayList<BarEntry> entries = new ArrayList<>();
            for (int i=0;i<10 ;i++){
                if(valores_grafica[i][0]!=null){
                    entries.add(new BarEntry(i, Float.parseFloat((valores_grafica[i][1]))));
                }
            }
            return entries;
    }

    private void axisX(XAxis axis,String [] x){
        axis.setGranularityEnabled(true);
        axis.setPosition(XAxis.XAxisPosition.BOTTOM);

        axis.setValueFormatter(new IndexAxisValueFormatter(x));
        axis.setEnabled(false);
    }

    private void axisLeft(YAxis axis){
        axis.setAxisMinimum(0);
        axis.setAxisMaximum(maximo+5);

    }
    private void axisRight(YAxis axis){
        axis.setEnabled(false);

    }

    public void createCharts(String [] x){
        barChart = (BarChart) getSameChart(barChart,"Afluencia", Color.RED,Color.WHITE,3000);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = metrics.widthPixels; // ancho absoluto en pixels
        int height = metrics.heightPixels; // alto absoluto en pixels
        barChart.getDescription().setPosition((float)width - 3.3f,(float)height - 3.3f);
        barChart.setDrawGridBackground(true);
        barChart.setDrawBarShadow(true);
        barChart.setData(getBarData());
        barChart.invalidate();

        axisX(barChart.getXAxis(),x);
        axisLeft(barChart.getAxisLeft());
        axisRight(barChart.getAxisRight());
    }

    private DataSet getData (DataSet dataSet){
        dataSet.setColors(Color.BLUE);
        dataSet.setValueTextSize(Color.WHITE);
        dataSet.setValueTextSize(10);
        return dataSet;
    }
    private BarData getBarData(){
        BarDataSet barDataSet = (BarDataSet) getData(new BarDataSet(getBarEntries(),""));
        barDataSet.setBarShadowColor(Color.LTGRAY);
        BarData barData = new BarData(barDataSet);
        barData.setBarWidth(0.45f);
        return barData;
    }

}
