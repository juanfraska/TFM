package com.academiaandroid.consultasmysql;

//Ejemplo aplicación Android que permite conectar con un servidor MySQl y realizar
//consultas sobre una base de datos creada.
//academiaandroid.com
//
//by José Antonio Gázquez Rodríguez

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConsultasAsincrona extends AsyncTask<String,Void,Integer>
{
    private Connection conexionMySQL;
    private Statement st = null;
    private ResultSet rs = null;

    @Override
    protected Integer doInBackground(String... datos)
    {

        String[] totalResultadoSQL = null;
        int num_rows= 0;
        String SERVIDOR = "192.168.1.129";
        String PUERTO = "3306";
        String BD = "DB_TFM";
        String USUARIO = "root";
        String PASSWORD = "aspire5920";
        String x= null;

        try{
            /*Establecemos la conexión con el Servidor MySQL indicándole la cadena de conexión formada por la dirección ip,
            puerto del servidor, la base de datos a la que vamos a conectarnos, y el usuario y contraseña de acceso al servidor.*/
            conexionMySQL = DriverManager.getConnection("jdbc:mysql://" + SERVIDOR + ":" + PUERTO + "/" + BD,
                    USUARIO,PASSWORD);

            String query = "select * from user where state = 'LOS'";
            //String query = "select * from user where DATE_FORMAT(FROM_UNIXTIME(discovered_at),'%a') = '5' ";

            Statement preparedStmt = conexionMySQL.createStatement();
            ResultSet rs = (ResultSet) preparedStmt.executeQuery(query);

            while(rs.next()){
                num_rows++;
                x=rs.getInt (1) + " " + rs.getString (2)+ " " + rs.getString(3) + " "+rs.getString(4) + " " +rs.getTimestamp(5)+ " " +rs.getTimestamp(6);

            }


        }catch(SQLException ex)
        {
            Log.d("No ha sido posible conectar con la base de datos", ex.getMessage());
        }
        finally
        {
            try
            {
                conexionMySQL.close();
            } catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
        return num_rows;
    }
}
