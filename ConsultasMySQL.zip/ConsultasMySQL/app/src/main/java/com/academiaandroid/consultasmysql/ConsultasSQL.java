/*package com.academiaandroid.consultasmysql;

//Ejemplo aplicación Android que permite conectar con un servidor MySQl y realizar
//consultas sobre una base de datos creada.
//academiaandroid.com
//
//by José Antonio Gázquez Rodríguez

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ConsultasSQL extends Activity {
	
	//Declaramos los componentes y clases necesarias para realizar consultas a una base de datos en MySQL
	private TextView txtBaseDatos,txtPuerto,txtServidor,txtUsuario,txtPass;
	private EditText edConsulta, edResultado;
	private Bundle bundle;
    private String[] datosConexion = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_consultas_sql);

		//Enlazamos los componentes con los recursos definidos en el layout
		txtServidor = (TextView)findViewById(R.id.txtServidor);
        txtPuerto = (TextView)findViewById(R.id.txtPuerto);
		txtUsuario = (TextView)findViewById(R.id.txtUsuario);
        txtPass = (TextView)findViewById(R.id.edPasswordCon);
        txtBaseDatos = (TextView)findViewById(R.id.txtBaseDatos);

        edConsulta = (EditText)findViewById(R.id.edConsulta);
        edResultado = (EditText)findViewById(R.id.edResultado);

        edResultado.setKeyListener(null);

		bundle = getIntent().getExtras();
		//Obtenemos los valores introducidos en la Activity principal
        txtServidor.setText(bundle.getString("servidor"));
		txtPuerto.setText(bundle.getString("puerto"));
        txtUsuario.setText(bundle.getString("usuario"));
        txtPass.setText(bundle.getString("password"));
		txtBaseDatos.setText(bundle.getString("datos"));
	}

    //Evento On Click que permite establecer una consulta básica sobre la tabla Cliente.
    public void consultaSelect(View view)
    {
        edConsulta.setText("Select * from Cliente");
    }



	//Evento On Click que conecta con el servidor MySQL y procesa las consultas mostrando los resultados
	public void mostrarResultados(View view)
	{
        String consulta = edConsulta.getText().toString();
        String[] resultadoSQL = null;
		try{
			if(consulta.equals(""))
			{
                Toast.makeText(this, "Debe indicar una consulta Transact-SQL válida.", Toast.LENGTH_LONG).show();
			}else
            {
                datosConexion = new String[]{
                                            txtServidor.getText().toString(),
                                            txtPuerto.getText().toString(),
                                            txtBaseDatos.getText().toString(),
                                            txtUsuario.getText().toString(),
                                            txtPass.getText().toString(),
                                            consulta
                                            };
                //Asignamos el driver a una variable de tipo String
                String driver = "com.mysql.jdbc.Driver";
                //Cargamos el driver del conector JDBC
                Class.forName(driver).newInstance ();
                resultadoSQL = new ConsultasAsincrona().execute(datosConexion).get();
                Toast.makeText(ConsultasSQL.this,"Conexión Establecida", Toast.LENGTH_LONG).show();

                String resultadoConsulta = resultadoSQL[0];
                String numFilas = resultadoSQL[1];
                String numColumnas = resultadoSQL[2];
                edResultado.setText(resultadoConsulta + "Número de filas devueltas: " +
                        numFilas + "\nNúmero de columnas devueltas: " + numColumnas);
            }
		}catch(Exception ex)
		{
			Toast.makeText(this, "Error al obtener resultados de la consulta Transact-SQL: " 
    				+ ex.getMessage(), Toast.LENGTH_LONG).show();
		}
	}
}
*/


