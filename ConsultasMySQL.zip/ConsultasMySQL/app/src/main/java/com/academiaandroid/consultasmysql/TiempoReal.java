package com.academiaandroid.consultasmysql;

import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

public class TiempoReal extends ActionBarActivity {
    private TextView num_personas;
    private Handler handler;
    private int numero_personas=0;
    Timer timer;
    MyTimerTask myTimerTask;
    public int cont_ejecucion=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tiempo_real);
        setTitle("Crowded APP - Datos en tiempo real");
        //Asignamos textview para mostrar las personas en tiempo real
        num_personas = (TextView)findViewById(R.id.num_personas);
        //Declaramos y lanzamos timer
        timer = new Timer();
        myTimerTask = new MyTimerTask();
        timer.schedule(myTimerTask, 1000, 5000);

    }

    class MyTimerTask extends TimerTask {

        @Override
        public void run() {
            runOnUiThread(new Runnable(){

                @Override
                public void run() {
                    try {
                        if(cont_ejecucion>15) timer.cancel();
                            numero_personas = new ConsultasAsincrona().execute("hold").get();
                            cont_ejecucion++;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                    num_personas.setText(Integer.toString(numero_personas) + " personas");
                }});
        }

    }




}



